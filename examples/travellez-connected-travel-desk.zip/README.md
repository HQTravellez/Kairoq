# Travellez Connected Travel Desk

Requires Node 22.13 or newer. Run npm start, then open http://localhost:3000. Deploy with npm start and persist workspace/ on a volume.

This export starts with a fresh built-in SQLite database. It does not contain users, sessions, production records or credentials. A Supabase-backed original is exported with the same schema and a fresh SQLite backend; its remote data is not migrated.

Downloaded assets and their credits are included. Provider workflows and the scenario plan are included when configured; add credentials and operation policies server-side. No provider execution history or production data is exported.
